/**
 * 
 */

function test(){
	alert("전 test.js파일에 있지만 저를 호출할수 있찌요!!");
}